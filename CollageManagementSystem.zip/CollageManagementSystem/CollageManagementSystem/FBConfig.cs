﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollageManagementSystem
{
    class FBConfig
    {
        public static string url = "https://logindata1-8fed2-default-rtdb.firebaseio.com/";
    }
}
